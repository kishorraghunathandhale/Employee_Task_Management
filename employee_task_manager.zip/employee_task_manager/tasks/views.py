from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from .models import Task
import pandas as pd


@login_required
def task_list(request):
    tasks = Task.objects.all()

    if request.user.role == 'EMPLOYEE':
        tasks = tasks.filter(assigned_to=request.user)

    search = request.GET.get('search')
    if search:
        tasks = tasks.filter(title__icontains=search)

    status = request.GET.get('status')
    if status:
        tasks = tasks.filter(status=status)

    priority = request.GET.get('priority')
    if priority:
        tasks = tasks.filter(priority=priority)

    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')
    if start_date and end_date:
        tasks = tasks.filter(deadline__range=[start_date, end_date])

    return render(request, 'tasks/task_list.html', {'tasks': tasks})


@login_required
def export_tasks_csv(request):
    tasks = Task.objects.all()

    if request.user.role == 'EMPLOYEE':
        tasks = tasks.filter(assigned_to=request.user)

    data = tasks.values(
        'title',
        'project__name',
        'assigned_to__username',
        'priority',
        'status',
        'deadline'
    )

    df = pd.DataFrame(list(data))
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="tasks.csv"'
    df.to_csv(response, index=False)
    return response


@login_required
def export_tasks_excel(request):
    tasks = Task.objects.all()

    if request.user.role == 'EMPLOYEE':
        tasks = tasks.filter(assigned_to=request.user)

    data = tasks.values(
        'title',
        'project__name',
        'assigned_to__username',
        'priority',
        'status',
        'deadline'
    )

    df = pd.DataFrame(list(data))
    response = HttpResponse(
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    response['Content-Disposition'] = 'attachment; filename="tasks.xlsx"'
    df.to_excel(response, index=False)
    return response
