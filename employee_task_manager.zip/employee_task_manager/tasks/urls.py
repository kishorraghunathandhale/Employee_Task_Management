from django.urls import path
from . import views

urlpatterns = [
    path('', views.task_list, name='task_list'),
    path('export/csv/', views.export_tasks_csv, name='export_tasks_csv'),
    path('export/excel/', views.export_tasks_excel, name='export_tasks_excel'),
]
