from django.shortcuts import render

# Create your views here.
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from .models import Notification


@login_required
def get_notifications(request):
    notifications = Notification.objects.filter(
        user=request.user,
        is_read=False
    ).order_by('-created_at')

    data = [
        {
            'id': n.id,
            'message': n.message,
            'created_at': n.created_at.strftime('%Y-%m-%d %H:%M')
        }
        for n in notifications
    ]

    return JsonResponse({'notifications': data})


@login_required
def mark_notification_read(request, pk):
    Notification.objects.filter(
        id=pk,
        user=request.user
    ).update(is_read=True)

    return JsonResponse({'status': 'ok'})
