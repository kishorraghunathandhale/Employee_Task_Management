from django.db.models.signals import post_save
from django.dispatch import receiver
from tasks.models import Task
from .models import Notification


@receiver(post_save, sender=Task)
def task_notification(sender, instance, created, **kwargs):
    if created:
        Notification.objects.create(
            user=instance.assigned_to,
            message=f'New task assigned: {instance.title}'
        )
    else:
        Notification.objects.create(
            user=instance.assigned_to,
            message=f'Task status updated: {instance.title} ({instance.status})'
        )
