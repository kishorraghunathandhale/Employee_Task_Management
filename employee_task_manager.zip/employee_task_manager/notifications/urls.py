from django.urls import path
from . import views

urlpatterns = [
    path('list/', views.get_notifications, name='get_notifications'),
    path('read/<int:pk>/', views.mark_notification_read, name='mark_notification_read'),
]
