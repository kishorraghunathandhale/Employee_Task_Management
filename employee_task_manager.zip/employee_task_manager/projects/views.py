from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.utils.timezone import now
from accounts.models import User
from .models import Project


def admin_manager_required(view_func):
    def wrapper(request, *args, **kwargs):
        if request.user.role in ['ADMIN', 'MANAGER']:
            return view_func(request, *args, **kwargs)
        return redirect('dashboard')
    return wrapper


@login_required
@admin_manager_required
def project_list(request):
    projects = Project.objects.all().prefetch_related('tasks')

    project_data = []

    for project in projects:
        total_tasks = project.tasks.count()
        completed_tasks = project.tasks.filter(status='COMPLETED').count()

        if total_tasks == 0:
            status = 'No Tasks'
        elif completed_tasks == total_tasks:
            status = 'Completed'
        else:
            status = 'In Progress'

        project_data.append({
            'project': project,
            'status': status,
            'total_tasks': total_tasks,
            'completed_tasks': completed_tasks
        })

    return render(request, 'projects/project_list.html', {
        'projects': project_data
    })


@login_required
@admin_manager_required
def project_create(request):
    employees = User.objects.filter(role='EMPLOYEE')

    if request.method == 'POST':
        assigned_to_id = request.POST.get('assigned_to')
        assigned_to = None

        if assigned_to_id:
            assigned_to = User.objects.get(id=assigned_to_id)

        Project.objects.create(
            name=request.POST.get('name'),
            description=request.POST.get('description'),
            start_date=request.POST.get('start_date'),
            end_date=request.POST.get('end_date'),
            assigned_to=assigned_to,
            created_by=request.user
        )
        return redirect('project_list')

    return render(request, 'projects/project_form.html', {
        'employees': employees
    })


@login_required
@admin_manager_required
def project_update(request, pk):
    project = get_object_or_404(Project, pk=pk)
    employees = User.objects.filter(role='EMPLOYEE')

    if request.method == 'POST':
        assigned_to_id = request.POST.get('assigned_to')
        project.assigned_to = (
            User.objects.get(id=assigned_to_id)
            if assigned_to_id else None
        )
        project.name = request.POST.get('name')
        project.description = request.POST.get('description')
        project.start_date = request.POST.get('start_date')
        project.end_date = request.POST.get('end_date')
        project.save()
        return redirect('project_list')

    return render(request, 'projects/project_form.html', {
        'project': project,
        'employees': employees
    })


@login_required
@admin_manager_required
def project_delete(request, pk):
    project = get_object_or_404(Project, pk=pk)
    project.delete()
    return redirect('project_list')


@login_required
def employee_projects(request):
    projects = Project.objects.filter(
        assigned_to=request.user
    ).prefetch_related('tasks')

    today = now().date()
    data = []

    for project in projects:
        total_tasks = project.tasks.count()
        completed_tasks = project.tasks.filter(status='COMPLETED').count()

        if total_tasks == 0:
            status = 'No Tasks'
        elif completed_tasks == total_tasks:
            status = 'Completed'
        else:
            status = 'In Progress'

        overdue = project.end_date < today and status != 'Completed'

        data.append({
            'project': project,
            'total_tasks': total_tasks,
            'completed_tasks': completed_tasks,
            'status': status,
            'overdue': overdue
        })

    return render(request, 'projects/employee_projects.html', {
        'projects': data
    })
