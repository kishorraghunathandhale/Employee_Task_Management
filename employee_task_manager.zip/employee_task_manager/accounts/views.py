from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.utils.timezone import now
from .models import ActivityLog
from projects.models import Project
from tasks.models import Task


def login_view(request):
    if request.method == 'POST':
        user = authenticate(
            request,
            username=request.POST.get('username'),
            password=request.POST.get('password')
        )
        if user:
            login(request, user)
            return redirect('dashboard')
        return render(request, 'accounts/login.html', {'error': 'Invalid credentials'})
    return render(request, 'accounts/login.html')


@login_required
def dashboard_redirect(request):
    user = request.user
    today = now().date()

    if user.role in ['ADMIN', 'MANAGER']:
        context = {
            'total_projects': Project.objects.count(),
            'total_tasks': Task.objects.count(),
            'pending_tasks': Task.objects.filter(status='PENDING').count(),
            'in_progress_tasks': Task.objects.filter(status='IN_PROGRESS').count(),
            'completed_tasks': Task.objects.filter(status='COMPLETED').count(),
            'overdue_tasks': Task.objects.filter(deadline__lt=today).exclude(status='COMPLETED').count()
        }
        if user.role == 'ADMIN':
            return render(request, 'accounts/admin_dashboard.html', context)
        return render(request, 'accounts/manager_dashboard.html', context)

    my_tasks = Task.objects.filter(assigned_to=user)
    return render(request, 'accounts/employee_dashboard.html', {
        'total_tasks': my_tasks.count(),
        'pending_tasks': my_tasks.filter(status='PENDING').count(),
        'completed_tasks': my_tasks.filter(status='COMPLETED').count()
    })


@login_required
def profile_view(request):
    return render(request, 'accounts/profile.html')


@login_required
def activity_log_view(request):
    logs = ActivityLog.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'accounts/activity_logs.html', {'logs': logs})


@login_required
def logout_view(request):
    logout(request)
    return redirect('login')
