from django.db.models.signals import post_save
from django.dispatch import receiver
from django.db.utils import OperationalError
from .models import ActivityLog
from tasks.models import Task
from projects.models import Project


@receiver(post_save, sender=Task)
def task_activity(sender, instance, created, **kwargs):
    try:
        if created:
            ActivityLog.objects.create(
                user=instance.assigned_to,
                action=f'Task assigned: {instance.title}'
            )
        else:
            ActivityLog.objects.create(
                user=instance.assigned_to,
                action=f'Task updated: {instance.title} ({instance.status})'
            )
    except OperationalError:
        pass


@receiver(post_save, sender=Project)
def project_activity(sender, instance, created, **kwargs):
    try:
        if created:
            ActivityLog.objects.create(
                user=instance.created_by,
                action=f'Project created: {instance.name}'
            )
    except OperationalError:
        pass
