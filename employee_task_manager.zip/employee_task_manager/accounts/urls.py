from django.urls import path
from . import views

urlpatterns = [
    path('', views.login_view, name='login'),
    path('dashboard/', views.dashboard_redirect, name='dashboard'),
    path('profile/', views.profile_view, name='profile'),
    path('activity/', views.activity_log_view, name='activity_logs'),
    path('logout/', views.logout_view, name='logout'),
]
